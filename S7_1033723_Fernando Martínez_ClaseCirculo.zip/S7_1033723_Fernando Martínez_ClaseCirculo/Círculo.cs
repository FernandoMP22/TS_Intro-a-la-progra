﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S7_1033723_Fernando_Martínez_ClaseCirculo
{
    public class circulo
    {
        double pi = Math.PI;


        private double radio;

        public circulo(double Radio)
        {

            radio = Radio;

        }
        private double GetPerimetro()
        {

            return 2 * radio * pi;

        }
        private double GetArea()
        {
            double potencia = Math.Pow(radio, 2);
            return pi * potencia;
        }
        private double GetVolumen()
        {
            double potencia = Math.Pow(radio, 3);
            return (4 * pi * potencia) / (3);
        }

        public void CalculoGeometria(ref double Perimetro, ref double Area, ref double Volumen)
        {
            Perimetro = GetPerimetro();
            Area = GetArea();
            Volumen = GetVolumen();
        }
    }
}
