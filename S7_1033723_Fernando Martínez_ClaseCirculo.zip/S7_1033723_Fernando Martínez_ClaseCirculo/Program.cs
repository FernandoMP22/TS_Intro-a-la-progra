﻿using S7_1033723_Fernando_Martínez_ClaseCirculo;

public class Program
{
    public static void Main(string[] args)
    {
        // Se le pide al usuario que ingrese los datos
        Console.WriteLine("Ingrese los datos del radio: ");
        double radio = int.Parse(Console.ReadLine());

        // Instancia de la clase = Objeto
        circulo objCirculo = new circulo(radio);

        double Perimetro = 0.0;
        double Area = 0.0;
        double Volumen = 0.0;

        objCirculo.CalculoGeometria(ref Perimetro, ref Area, ref Volumen);

        // Se imprimen los datos obtenidos
        Console.WriteLine("el perimetro es: " + Perimetro);
        Console.WriteLine("el area es: " + Area);
        Console.WriteLine("el volumen es: " + Volumen);

    }
}